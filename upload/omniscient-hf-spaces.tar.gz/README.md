---
title: OMNISCIENT
emoji: 📊
colorFrom: blue
colorTo: indigo
sdk: docker
app_port: 7860
pinned: false
license: mit
---

# OMNISCIENT — Global Market Intelligence System

24/7 AI-powered global market intelligence. Crypto, forex, commodities, indices, stocks, IPOs/ICOs, macro economy — multi-LLM deep analysis with Telegram alerts.

## Quick Start

This Space auto-builds from the Dockerfile. No manual setup needed.

**Default password:** `omniscient` (change in Settings → Security after first login)

## Features

- **22 pages**: Overview, Crypto, Markets, Heat Map, Correlation, Screener, Signals, Derivatives, Multi-TF, Alerts, Portfolio, Risk Calc, Backtest, Strategy Builder, Analytics, News, Macro, Econ Calendar, IPO/ICO, Notifications, Reports, Settings
- **11 LLM providers** with auto-fallback + multi-key rotation
- **Binance WebSocket** real-time prices
- **RSS news feeds** + LLM sentiment analysis
- **Apple Liquid Glass UI** with shadcn/ui (radix-rhea)
- **Prisma ORM** (SQLite baked into image)
- **Telegram alerts**

See PROJECT_GUIDE.txt for the complete technical documentation.
